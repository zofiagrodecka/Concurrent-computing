Zeszło mi z półtorej godziny, żeby to wszystko ładnie zebrać. Mam nadzieję, że się przyda i będzie dobrze wykorzystane.

Ćwiczenia 7 i 10 są z programu POWER (może raczej POWNED?). O ćwiczeniu 3 (js) wiemy, że też, choć nie ma tej strony tytułowej w pdfie. Nwm jak z resztą ćwiczeń...

Tematy ćwiczeń:
1. Wątki oraz synchronizacja w Javie (nie było zadania)
2. Oczekiwanie na warunek w Javie
3. Filozofowie Java + Node
4. Wstęp do śladów (Java)
5. Dalej ślady, zadanie w (dowolnym) języku funkcyjnym (tu: emacs lisp) (przechodziły też języki niefunkcyjne (np. java (ktoś w niej zrobił)) z zastosowaniem biblioteki funkcyjnej (e.g. functionaljava))
6. Ślady z szeregowaniem wątków do równoległej eliminacji Gaussa. Dużo osób miało ucięte punkty za złą relację (nie)zależności i w konsekwencji graf Diekerta - tutaj wszystko ok ^^ Zadanie w dowolonym języku z wątkami - tu C z pthreads. Największe zadanie w semestrze - kilka tygodni na zrobienie, Woźniak poświęcił jakieś półtora labu, żeby każdemu osobiście sprawdzić. Były błędy zarówno w javowej sprawdzarce Woźniaka, jak i w jego slajdach z wykładu, konkretnie w relacji (nie)zależności i w konsekwencji w grafie Diekerta...
7. Wprowadzenie do sieci Petri (program PIPE)
8. Dalej sieci Petri (dalej program PIPE)
9. Blokowanie drobnoziarniste (w Javie) (nie było zadania, to chyba na tym labie mnożył zdobyte plusy razy 2)
10. CSP (bibioteka JCSP w javie, chyba jest w repo Debiana)
